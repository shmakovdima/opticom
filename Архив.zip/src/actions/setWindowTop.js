export function setWindowTop(top) {
  return {
    type: 'SET_WINDOWTOP',
    payload: top
  }
}