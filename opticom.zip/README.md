# react-router-course-ru
Код для раздела [Дописываем роуты](https://maxfarseer.gitbooks.io/react-router-course-ru/content/dopisivaem_routi.html)
