import React, { Component } from 'react'
import Header from './Header'

export default class HeaderDark extends Component {
  render() {
    return (
      <header className='header header_dark'>
        <Header/>
      </header>
    )
  }
} 