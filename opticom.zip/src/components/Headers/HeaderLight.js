import React, { Component } from 'react'
import Header from './Header'

export default class HeaderLight extends Component {
  render() {
    return (
      <header className='header header_light'>
        <Header/>
      </header>
    )
  }
} 